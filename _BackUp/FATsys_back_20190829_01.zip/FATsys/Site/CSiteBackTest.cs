﻿using System;
using System.IO;
using System.Collections.Generic;
using CsvHelper;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using System.Threading.Tasks;
using FATsys.TraderType;
using FATsys.Utils;

namespace FATsys.Site
{
    class CSiteBackTest : CSite
    {
        private int m_nPos_rate;
        private Dictionary<string, List<TRatesTick>> m_ratesTick = new Dictionary<string, List<TRatesTick>>();
        /// <summary>
        /// load backtest tick rates from file
        /// </summary>
        public override void loadRates_Tick()
        {
            string sFile = "";
            foreach (string sSym in m_sSymbols)
            {
                sFile = Path.Combine(Application.StartupPath, "_log\\backtest_rates\\" + m_sSiteName,sSym + ".csv");
                CFATLogger.output_proc("loadRates_Tick : ----->" + sFile);
                var objSR = new StreamReader(sFile);
                var objCSVR = new CsvReader(objSR);
                objCSVR.Configuration.HasHeaderRecord = false;
                List<TRatesTick> objRecords = new List<TRatesTick>();
                objRecords = objCSVR.GetRecords<TRatesTick>().ToList();
                m_ratesTick.Add(sSym, objRecords);
                CFATLogger.output_proc("loadRates_Tick : <-----" + sFile);
            }
        }

        public override bool OnInit()
        {
            m_nPos_rate = 0;
            return base.OnInit();
        }
        public override EERROR OnTick()
        {
            int nRatesCnt = 0;
            foreach(string sSym in m_sSymbols)
            {
                m_rates[sSym] = m_ratesTick[sSym][m_nPos_rate];
                nRatesCnt = m_ratesTick[sSym].Count;
            }

            m_nPos_rate++;
            if (m_nPos_rate == nRatesCnt) return EERROR.RATE_END;

            return base.OnTick();
        }

        public override void OnDeInit()
        {
            base.OnDeInit();
        }

        public override void makeReport()
        {
            base.makeReport();
        }

    }
}
