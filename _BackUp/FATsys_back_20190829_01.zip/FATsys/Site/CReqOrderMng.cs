﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using FATsys.Utils;
using FATsys.TraderType;

namespace FATsys.Site
{
    class CReqOrderMng
    {
        private static List<TReqOrder> m_lstReqOrders = new List<TReqOrder>();
        private static List<TReqOrder> m_lstMergeReqOrders = new List<TReqOrder>();

        public void clearReqOrders()
        {
            m_lstReqOrders.Clear();
            m_lstMergeReqOrders.Clear();
        }

        public int registerOrder(TReqOrder reqOrder)
        {
            m_lstReqOrders.Add(reqOrder);
            return 0;
        }

        //Here is Main fucntion
        // merge -> sort by priority -> process -> set result
        public bool process_ReqOrders()
        {
            if (m_lstReqOrders.Count == 0)
                return true;

            //1. merge orders
            bool bRet = merge_reqOrders();

            if (!bRet)
                return false;

            //2. sort by priority
            sortMergeReqOrders_ByPriority();

            double dReqLots_depends = 0;
            double dExcLots_depends = 0;

            //3. process order
            foreach (TReqOrder reqMergeOrder in m_lstMergeReqOrders)
            {
                if ( reqMergeOrder.m_nDependProduct > 0 )
                {
                    if (!getLots_fromDependsProduct(reqMergeOrder.m_nDependProduct, ref dReqLots_depends, ref dExcLots_depends))
                        return false;
                    reqMergeOrder.m_dLots_req = reqMergeOrder.m_dLots_req * dExcLots_depends / dReqLots_depends; //How can we normalize double for digits ????
                }
                reqMergeOrder.reqOrder();
            }

            //4. set result
            setResult_subReqOrders();
            return true;
        }

        private void setResult_subReqOrders()
        {
            foreach ( TReqOrder reqMergeOrder in m_lstMergeReqOrders)
            {
                reqMergeOrder.setResult_subReqOrders();
            }
        }
        private bool getLots_fromDependsProduct(int nProductCode, ref double dLots_req, ref double dLots_exc)
        {
            foreach(TReqOrder reqMergeOrder in m_lstMergeReqOrders)
            {
                if ( reqMergeOrder.getProductCode() == nProductCode )
                {
                    if (!reqMergeOrder.m_bProcessed) return false;

                    dLots_req = reqMergeOrder.m_dLots_req;
                    dLots_exc = reqMergeOrder.m_dLots_exc;
                    return true;
                }
            }
            return false;
        }
        private void sortMergeReqOrders_ByPriority()
        {
            TReqOrder reqOrderTmp;
            for ( int i = 0; i < m_lstMergeReqOrders.Count-1; i ++ )
            {
                for ( int k = i+1; k < m_lstMergeReqOrders.Count; k ++ )
                {
                    if ( m_lstMergeReqOrders[i].m_nPriority > m_lstMergeReqOrders[k].m_nPriority)
                    {
                        reqOrderTmp = m_lstMergeReqOrders[i];
                        m_lstMergeReqOrders[i] = m_lstMergeReqOrders[k];
                        m_lstMergeReqOrders[k] = reqOrderTmp;
                    }
                }
            }
        }
        private bool merge_reqOrders()
        {
            TReqOrder reqMergeOrder = new TReqOrder();
            foreach (TReqOrder reqOrder in m_lstReqOrders)
            {
                if (isMergedProduct(reqOrder.getProductCode()))// If already merged then skip
                    continue;
                if (!merge_reqOrders_product(reqOrder.getProductCode())) //If invalid reqOrders for merge such as different req price, 
                                                                            //different req market type, different req order type .. and so on 
                {
                    return false;
                }
            }
            return true;
        }

        private bool isMergedProduct(int nProductCode)
        {
            foreach (TReqOrder reqMergeOrder in m_lstMergeReqOrders)
            {
                if (reqMergeOrder.getProductCode() == nProductCode)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Merge reqOrders by product code ( defined by site & symbol)
        /// There is some problems.
        /// 1. IF different to request price on each logic
        /// 2. IF different to order type on each logic
        /// 3. IF different to priority on each logic
        /// </summary>
        /// <param name="nProductCode"></param>
        /// <returns></returns>
        private bool merge_reqOrders_product(int nProductCode)
        {
            TReqOrder reqMergeOrder = new TReqOrder();
            double dMergeLots = 0;
            foreach (TReqOrder reqOrder in m_lstReqOrders)
            {
                if (reqOrder.getProductCode() != nProductCode)
                    continue;
                reqMergeOrder.setVal(reqOrder.m_product, ETRADER_OP.NONE, 0, reqOrder.m_dPrice_req, 
                    reqOrder.m_nOrderType, reqOrder.m_nPriority, reqOrder.m_nDependProduct, "");

                if (reqOrder.m_nCmd == ETRADER_OP.BUY || reqOrder.m_nCmd == ETRADER_OP.SELL_CLOSE)
                    dMergeLots += reqOrder.m_dLots_req;
                if (reqOrder.m_nCmd == ETRADER_OP.SELL || reqOrder.m_nCmd == ETRADER_OP.BUY_CLOSE)
                    dMergeLots -= reqOrder.m_dLots_req;
                reqMergeOrder.m_lstReqOrders.Add(reqOrder);// register sub req orders...
            }

            if (Math.Abs(dMergeLots) < CFATCommon.ESP)
                return true;

            if (dMergeLots > CFATCommon.ESP)
                reqMergeOrder.m_nCmd = ETRADER_OP.BUY;

            if (dMergeLots < 0)
                reqMergeOrder.m_nCmd = ETRADER_OP.SELL;

            reqMergeOrder.m_dLots_req = Math.Abs(dMergeLots);

            m_lstMergeReqOrders.Add(reqMergeOrder);
            return true;
        }
    }
}
