﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using FATsys.Product;
using FATsys.Utils;
using FATsys.TraderType;

namespace FATsys.Logic.Indicators
{
    class CIndBand : CIndicator
    {
        

        private double m_dBand_up = 0;
        private double m_dBand_mid = 0;
        private double m_dBand_down = 0;

        private CIndMA m_indMA = new CIndMA();
        private CIndStd m_indSTD = new CIndStd();

        public CIndBand()
        {
            m_sName = "IndBand";
        }

        public void setCacheData(CCacheData cacheData)
        {
            m_cacheData_A = cacheData;

            m_indMA.setCacheData(cacheData);
            m_indSTD.setCacheData(cacheData);
        }

        public void calc(int nPeriod, ETIME_FRAME nTimeFrame = ETIME_FRAME.MIN1, EPRICE_MODE nPriceMode = EPRICE_MODE.BID, EPRICE_VAL nPriceVal = EPRICE_VAL.CLOSE)
        {
            m_indSTD.calc(nPeriod, nTimeFrame, nPriceMode, nPriceVal);
            m_indMA.calc(nPeriod, nTimeFrame, nPriceMode, nPriceVal);

            double dStd = m_indSTD.getVal();

            m_dBand_mid = m_indMA.getVal();
            m_dBand_up = m_dBand_mid + 2 * dStd;
            m_dBand_down = m_dBand_mid - 2 * dStd;
        }

        public void getVal(ref double dBand_up, ref double dBand_mid, ref double dBand_down)
        {
            dBand_up = m_dBand_up;
            dBand_mid = m_dBand_mid;
            dBand_down = m_dBand_down;
        }

        public int getSignal()
        {
            int nRetSignal = (int)ETRADER_OP.NONE;

            if (m_cacheData_A.getTick(0).dAsk < m_dBand_down)
                nRetSignal |= (int)ETRADER_OP.BUY;

            if (m_cacheData_A.getTick(0).dBid > m_dBand_up)
                nRetSignal |= (int)ETRADER_OP.SELL;

            if (m_cacheData_A.getTick(0).dBid > m_dBand_up)
                nRetSignal |= (int)ETRADER_OP.BUY_CLOSE;

            if (m_cacheData_A.getTick(0).dAsk < m_dBand_down)
                nRetSignal |= (int)ETRADER_OP.SELL_CLOSE;

            return nRetSignal;
        }


    }
}
