﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using FATsys.Utils;
using FATsys.TraderType;
using FATsys.Product;
using FATsys.Logic.Indicators;

namespace FATsys.Logic
{
    class CLogic_Pair_V1 : CLogic
    {
        double ex_dOpenLevel;
        double ex_dCloseLevel;
        double ex_dSlippage;
        int ex_nMAPeriod = 30;
        double ex_dRenkoStep;

        CProductCFD m_product_diff = new CProductCFD();
        CIndMA m_indMA = new CIndMA();
        CIndCC m_indCC = new CIndCC();

        TBenchMarking m_benchMarking = new TBenchMarking();

        public override void loadParams()
        {
            ex_dOpenLevel = m_params.getVal_double("ex_dOpenLevel");
            ex_dCloseLevel = m_params.getVal_double("ex_dCloseLevel");
            ex_dSlippage = m_params.getVal_double("ex_dSlippage");
            ex_nMAPeriod = (int)m_params.getVal_double("ex_nMAPeriod");
            ex_dRenkoStep = m_params.getVal_double("ex_dRenkoStep");

            base.loadParams();
        }

        public override bool OnInit()
        {
            //ProductCFD define
            
            m_product_diff.setProductA(m_products[0]); //SH Gold
            m_product_diff.setProductB(m_products[1]); //LD Gold
            m_product_diff.setProductC(m_products[2]); //USDCNY

            m_product_diff.setProductInfo(m_sLogicID, "SH_LD_DIFF");
            m_product_diff.setProductType(EPRODUCT_TYPE_PRICE.A_BC, EPRODUCT_TYPE_TRADE.A_BC);

            m_product_diff.setRenkoInfo(true, ex_dRenkoStep);

            m_product_diff.setName();

            m_product_diff.OnInit(); //load data from xml file
            //-----------------------------------------------------

            //Indicator define
            m_indMA.setCacheData(m_product_diff.getCacheData());
            m_indCC.setCacheData(m_product_diff.getCacheData_rk(0), m_product_diff.getCacheData_rk(1));
            //-----------------------------------------------------


            loadParams();
            return base.OnInit();
        }

        public override void OnDeInit()
        {
            m_product_diff.OnDeInit();
            base.OnDeInit();
        }

        public override int OnTick()
        {
            if (CFATManager.isOnlineMode())
                m_benchMarking.push_Ontick_start(DateTime.Now); //For bench marking

            updateState_v2(40, 20, 60);//wait check pos : 40s, wait force close : 20s , restart logic after stop by error : 60s

            //Here is update price and indicators pattern
            //First update price, after update indicators
            m_product_diff.updateRates();
            updateIndicators();
            //----------------------------------------------

            if (m_stState.m_nState == ELOGIC_STATE.NORMAL)
            {
                checkForClose();
                checkForOpen();
            }

            publishToMQ();//For Manager

            if (CFATManager.isOnlineMode())
                m_benchMarking.push_Ontick_end(DateTime.Now);   //For bench marking

            return base.OnTick();
        }

        private void checkForClose()
        {
            if ( m_product_diff.getPosCount_vt() == 0)
                return;

            int nSignal = getSignal();
            ETRADER_OP nCmd = m_product_diff.getPosCmd_vt(0);

            double dLots = ex_dLots;
            if (nCmd == ETRADER_OP.BUY && TRADER.isContain(nSignal, (int)ETRADER_OP.BUY_CLOSE))
                requestOrder(ETRADER_OP.BUY_CLOSE);

            if (nCmd == ETRADER_OP.SELL && TRADER.isContain(nSignal, (int)ETRADER_OP.SELL_CLOSE))
                requestOrder(ETRADER_OP.SELL_CLOSE);
        }

        private void checkForOpen()
        {
            if (m_product_diff.getPosCount_vt() > 0)
                return;

            int nSignal = getSignal();

            if (TRADER.isContain(nSignal, (int)ETRADER_OP.BUY))
            {
                if (ex_nIsNewOrder > 0)
                    requestOrder(ETRADER_OP.BUY);
            }

            if (TRADER.isContain(nSignal, (int)ETRADER_OP.SELL))
            {
                if (ex_nIsNewOrder > 0)
                    requestOrder(ETRADER_OP.SELL);
            }
        }

        public void requestOrder(ETRADER_OP nCmd)
        {
            if (nCmd == ETRADER_OP.BUY || nCmd == ETRADER_OP.SELL)
                setParam_newOrder(ex_nIsNewOrder - 1);

            CFATLogger.output_proc(string.Format("Order : {0}, diff = {1}", nCmd.ToString(), m_product_diff.m_dMid));
            m_product_diff.requestOrder(nCmd, ex_dLots);

            setState(ELOGIC_STATE.NEED_CHECK_POSITION_MATCH);
        }



        private int getSignal()
        {
            int nSigMA = m_indMA.getSignal(ex_dOpenLevel, ex_dCloseLevel);
            int nSigCC = m_indCC.getSignal(ex_dOpenLevel, ex_dCloseLevel);

            return nSigCC;
        }

        public void updateIndicators()
        {
            m_indMA.calc(ex_nMAPeriod);
            m_indCC.calc(ex_nMAPeriod);
        }

        public override void doForceClose()
        {
            clearAllPositions();
            setState(ELOGIC_STATE.WAITING_FORCE_CLOSE);
        }
        public override void waitOrderFilled()
        {
            if (!m_product_diff.isOrderFilled())
                return;
            setState(ELOGIC_STATE.NEED_CHECK_POSITION_MATCH);
        }
        #region ##### publish to MQ #########
        private void publish_rates_indicators()
        {
            if (CFATManager.m_nRunMode == ERUN_MODE.OPTIMIZE)
                return;


            if (CFATManager.m_nRunMode == ERUN_MODE.BACKTEST)
            {
                m_product_diff.publish_min();
                m_indCC.publish_min();
                return;
            }

            if (CFATManager.isOnlineMode())
            {
                m_product_diff.publish_tick();
                m_indCC.publish_tick();
                return;
            }
        }

        public override void publishVariables()
        {
            m_vars_publish.Clear();
            m_vars_publish.Add("diff", m_product_diff.m_dMid.ToString());
            m_vars_publish.Add("SH price", m_products[0].getBid().ToString());
            m_vars_publish.Add("XAUUSD", m_products[1].getBid().ToString());
            m_vars_publish.Add("USDCNH", m_products[2].getBid().ToString());
            m_vars_publish.Add("logicState", m_stState.m_nState.ToString());
            m_vars_publish.Add("bench_start_start", m_benchMarking.getAverageMilliSecs_start_start(100).ToString());
            m_vars_publish.Add("bench_start_end", m_benchMarking.getAverageMilliSecs_start_end(100).ToString());
            base.publishVariables();
        }

        private void publishToMQ()
        {
            publish_rates_indicators();

            if (!CFATManager.isOnlineMode())
                return;

            if ((DateTime.Now - m_dtLastPublish).TotalSeconds < 2) //every 2 seconds publish message
                return;

            try
            {
                //parameters : 
                publishParams();
                //history
                publishTradeHistory();
                //Variables
                publishVariables();

                if (m_stState.m_nState == ELOGIC_STATE.LOGIC_STOP_BY_ERROR)
                    CFATLogger.output_proc(string.Format(" **** {0} Logic Stoped!!!", m_sLogicID));

                m_dtLastPublish = DateTime.Now;
            }
            catch
            {
                CFATLogger.output_proc("CLogic_Arb_org : publishToMQ error!");
            }
        }
        #endregion

        private void clearAllPositions()
        {
            CFATLogger.output_proc(string.Format("{0} : Position UnMatched!, clear position !!! ************** ", m_sLogicID));
            m_product_diff.clearPositions();
        }
    }
}
