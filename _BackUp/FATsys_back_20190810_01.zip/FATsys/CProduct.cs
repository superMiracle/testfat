﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using FATsys.Site;
using FATsys.Utils;
using FATsys.TraderType;

namespace FATsys
{
    class CProduct
    {
        private string m_sSymbol;
        private CSite m_site;
        private string m_sLogicID;
        private double m_dContractSize = 1;

        public double m_dBid;
        public double m_dAsk;
        public double m_dMid;
        public double m_dBid_published;
        public double m_dAsk_published;

        public void getRates()
        {
            m_dBid = getBid();
            m_dAsk = getAsk();
            m_dMid= (m_dBid + m_dAsk) / 2;
        }
        public void setSite(CSite site)
        {
            m_site = site;
        }

        public void setContractSize(double dContractSize)
        {
            m_dContractSize = dContractSize;
        }

        public void setLogicID(string sLogicID)
        {
            m_sLogicID = sLogicID;
        }

        public void clearPositions()
        {
            //Clear Virtual positions
            m_site.clearVirtualPositions(m_sSymbol);

            //Clear Real positions
            double dLots = m_site.getPosLots_Total_real(m_sSymbol);
            if (Math.Abs(dLots) < CFATCommon.ESP)
                return;
            ETRADER_OP nCmd = ETRADER_OP.NONE;

            if (dLots > 0) // Buy 
                nCmd = ETRADER_OP.BUY_CLOSE;
            else // Sell
                nCmd = ETRADER_OP.SELL_CLOSE;

            double dReqLots = Math.Abs(dLots);
            double dReqPrice = 0;

            if (nCmd == ETRADER_OP.BUY_CLOSE) //Sell
                dReqPrice = getTick(0).dBid;

            if (nCmd == ETRADER_OP.SELL_CLOSE) //Buy
                dReqPrice = getTick(0).dAsk;

            reqOrder(nCmd, ref dReqLots, ref dReqPrice, EORDER_TYPE.MARKET);
        }

        public void updateRealPositions()
        {
            m_site.updateRealPositions();
        }

        public bool isPositionMatch()
        {
            if ( Math.Abs(m_site.getPosLots_Total_virtual(m_sSymbol) - m_site.getPosLots_Total_real(m_sSymbol)) < CFATCommon.ESP )
                return true;
            m_site.updateRealPositions();

            if (Math.Abs(m_site.getPosLots_Total_virtual(m_sSymbol) - m_site.getPosLots_Total_real(m_sSymbol) ) < CFATCommon.ESP)
                return true;
            return false;
        }
        public void matchPosReal2Virtual()
        {
            m_site.matchPosReal2Virtual(m_sSymbol, m_sLogicID);
        }
        public void matchPosVirtual2Real()
        {
            double dLots_real = m_site.getPosLots_Total_real(m_sSymbol);
            double dLots_virtual = m_site.getPosLots_Total_virtual(m_sSymbol);

            double dLots_diff = dLots_virtual - dLots_real;
            
            double dAsk = getTick(0).dAsk;
            double dBid = getTick(0).dBid;
            if (Math.Abs(dLots_diff) < CFATCommon.ESP)
                return;

            if ( dLots_diff > 0 )
            {// new buy or close sell
                if (dLots_virtual > 0)
                {// new buy
                    reqOrder(ETRADER_OP.BUY, ref dLots_diff, ref dAsk, EORDER_TYPE.MARKET);
                }
                else
                {// close sell
                    reqOrder(ETRADER_OP.SELL_CLOSE, ref dLots_diff, ref dAsk, EORDER_TYPE.MARKET);
                }
            }

            if ( dLots_diff < 0)
            {// new sell or close buy
                if ( dLots_virtual < 0)
                {// new sell
                    reqOrder(ETRADER_OP.SELL, ref dLots_diff, ref dBid, EORDER_TYPE.MARKET);
                }
                else
                {// close buy
                    reqOrder(ETRADER_OP.BUY_CLOSE, ref dLots_diff, ref dBid, EORDER_TYPE.MARKET);
                }
            }
        }

        public void publish_tick()
        {
            string sTxt = "";
            if (m_dBid != m_dBid_published || m_dAsk != m_dAsk_published)
            {
                sTxt = string.Format("{0},{1},{2},{3},{4}", getSiteName(), getSymbol(), CFATCommon.m_dtCurTime, m_dBid, m_dAsk);
                CMQClient.publish_msg(sTxt, CFATCommon.MQ_TOPIC_PRICE_TICK);
                m_dBid_published = m_dBid;
                m_dAsk_published = m_dAsk;
            }
        }

        public void setSymbol(string sSymbol)
        {
            m_sSymbol = sSymbol;
        }
        public string getSymbol()
        {
            return m_sSymbol;
        }

        public string getSiteName()
        {
            return m_site.m_sSiteName;
        }

        public double getBid()
        {
            return m_site.getBid(m_sSymbol);
        }
        public double getAsk()
        {
            return m_site.getAsk(m_sSymbol);
        }

        public DateTime getTickTime()
        {
            return m_site.getTickTime(m_sSymbol);
        }
        public TRatesTick getTick(int nPos)
        {
            return m_site.getTick(m_sSymbol, nPos);
        }
        public int getTick_count()
        {
            return m_site.getTick_count(m_sSymbol);
        }

        
        public double getMA_tick(int nPeriod, EPRICE nPriceMode = EPRICE.MODE_BID, int nShift = 0)
        {
            return m_site.getMA_tick(m_sSymbol, nPeriod, nPriceMode, nShift);
        }
        public double getStd_tick(int nPeriod, EPRICE nPriceMode = EPRICE.MODE_BID)
        {
            return m_site.getStd_tick(m_sSymbol, nPeriod, nPriceMode);
        }

        public void getMinMax_tick(int nPeriod, ref int nMinPos, ref int nMaxPos, ref double dMin, ref double dMax, EPRICE nPriceMode = EPRICE.MODE_BID, int nPeriodMilliSec = -1)
        {
            m_site.getMinMax_tick(m_sSymbol, nPeriod, ref nMinPos, ref nMaxPos, ref dMin, ref dMax, nPriceMode, nPeriodMilliSec);
        }
        public double getPosLots_virtual()
        {
            return m_site.getPosLots_Total_virtual(m_sSymbol);
        }
        public double getPosLots_real()
        {
            if ( !CFATManager.isOnlineMode())
                return m_site.getPosLots_Total_virtual(m_sSymbol);
            return m_site.getPosLots_Total_real(m_sSymbol);
        }
        public int getPosCount()
        {
            return m_site.getPosCount(m_sSymbol, m_sLogicID);
        }
        public int getHistoryCount()
        {
            return m_site.getHistoryCount(m_sSymbol, m_sLogicID);
        }

        public ETRADER_OP getPosCmd(int nPosIndex)
        {
            return m_site.getPosCmd(m_sSymbol, nPosIndex, m_sLogicID);
        }
        public double getPosProfit_virtual(int nPosIndex)
        {
            return m_site.getPosProfit_virtual(m_sSymbol, nPosIndex, m_sLogicID);
        }
        public bool reqCloseAll(string sComment = "")
        {
            int nPosCnt = m_site.getPosCount(m_sSymbol, m_sLogicID);
            ETRADER_OP nCmd = ETRADER_OP.NONE;
            double dPrice = 0;
            double dLots = 0;
            for ( int i = 0; i < nPosCnt; i ++ )
            {
                nCmd = m_site.getPosCmd(m_sSymbol, i, m_sLogicID);
                if (nCmd == ETRADER_OP.BUY)
                    nCmd = ETRADER_OP.BUY_CLOSE;
                if (nCmd == ETRADER_OP.SELL)
                    nCmd = ETRADER_OP.SELL_CLOSE;

                dPrice = m_site.getPosClosePrice_req(m_sSymbol, i, m_sLogicID);
                dLots = m_site.getPosLots_exc(m_sSymbol, i, m_sLogicID);
                m_site.reqOrder(m_sSymbol, nCmd, ref dLots, ref dPrice, EORDER_TYPE.MARKET, m_sLogicID, sComment);
            }

            return true;
        }

        public bool reqOrder(ETRADER_OP nCmd, ref double dLots, ref double dPrice, EORDER_TYPE nOrderType, string sComment = "")
        {
            return m_site.reqOrder(m_sSymbol, nCmd, ref dLots, ref dPrice, nOrderType, m_sLogicID, sComment);
        }

        public void closeOrDelete()
        {//close last position or pending order.

        }
    }
}
