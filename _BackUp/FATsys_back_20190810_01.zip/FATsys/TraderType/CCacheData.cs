﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FATsys.Utils;

namespace FATsys.TraderType
{
    class CCacheData
    {
        private List<TRatesTick> m_tickData = new List<TRatesTick>();
        private List<TRatesMin> m_minData = new List<TRatesMin>();

        private int m_nCurPos_tick = -1;
        private int m_nCurPos_min = -1;

        public void clear()
        {
            m_nCurPos_tick = -1;
            m_nCurPos_min = -1;

            m_tickData.Clear();
            m_minData.Clear();
        }
        public void pushTick(double dAsk, double dBid, DateTime dtTime)
        {
            m_nCurPos_tick++;
            if (m_tickData.Count < CFATCommon.CACHE_SIZE)
            {
                TRatesTick tick = new TRatesTick();
                tick.dAsk = dAsk;
                tick.dBid = dBid;
                tick.m_dtTime = dtTime;
                m_tickData.Add(tick);
            }
            else
            {
                if (m_nCurPos_tick == CFATCommon.CACHE_SIZE)
                    m_nCurPos_tick = 0;
                m_tickData[m_nCurPos_tick].dAsk = dAsk;
                m_tickData[m_nCurPos_tick].dBid = dBid;
                m_tickData[m_nCurPos_tick].m_dtTime = dtTime;
            }
            pushMin(dAsk, dBid, dtTime);
        }

        public void pushMin(double dAsk, double dBid, DateTime dtTime)
        {
            bool bIsNewBar = false;
            if (m_minData.Count == 0)
                bIsNewBar = true;
            else
            {
                if ((dtTime - m_minData[m_nCurPos_min].m_dtTime).TotalSeconds >= 60) //60 s after new 1 min data
                    bIsNewBar = true;
            }

            if (bIsNewBar)
                m_nCurPos_min++;

            if (bIsNewBar && m_nCurPos_min < CFATCommon.CACHE_SIZE)
            {
                TRatesMin minData = new TRatesMin();
                minData.setVal(dAsk, dAsk, dAsk, dAsk, dBid, dBid, dBid, dBid);
                minData.m_dtTime = dtTime; //Set open time of 1 min
                m_minData.Add(minData);
                return;
            }

            if (m_nCurPos_min == CFATCommon.CACHE_SIZE)
                m_nCurPos_min = 0;

            m_minData[m_nCurPos_min].pushTick(dAsk, dBid);
        }

        public int getTickCount()
        {
            return m_tickData.Count;
        }
        public int getMinCount()
        {
            return m_minData.Count;
        }

        public TRatesTick getTick(int nPos)
        {
            if (m_tickData.Count == 0)
                return new TRatesTick();
            if (m_nCurPos_tick >= nPos)
                return m_tickData[m_nCurPos_tick - nPos];
            
            //int nRetPos = CFATCommon.CACHE_SIZE - (nPos - m_nCurPos_tick);
            int nRetPos = m_tickData.Count - (nPos - m_nCurPos_tick);
            if (nRetPos < 0) nRetPos = 0;
            if (nRetPos > m_tickData.Count - 1) nRetPos = m_tickData.Count - 1;
            return m_tickData[nRetPos];
        }
        public TRatesMin getMin(int nPos)
        {
            if (m_minData.Count == 0)
                return new TRatesMin();

            if (m_nCurPos_min >= nPos)
                return m_minData[m_nCurPos_min - nPos];

            //int nRetPos = CFATCommon.CACHE_SIZE - (nPos - m_nCurPos_tick);
            int nRetPos = m_minData.Count - (nPos - m_nCurPos_min);
            if (nRetPos < 0) nRetPos = 0;
            if (nRetPos > m_minData.Count - 1) nRetPos = m_minData.Count - 1;

            return m_minData[nRetPos];
        }

        public double getMA_tick(int nPeriod, EPRICE nPriceMode = EPRICE.MODE_BID, int nShift = 0)
        {
            double dSum = 0;
            if (nPeriod == 0)
                return 0;
            TRatesTick tick;
            for ( int i = nShift; i < nPeriod + nShift; i ++ )
            {
                tick = getTick(i);
                if ( nPriceMode == EPRICE.MODE_BID)
                    dSum += tick.dBid;

                if (nPriceMode == EPRICE.MODE_ASK)
                    dSum += tick.dAsk;

                if (nPriceMode == EPRICE.MODE_MIDDLE)
                    dSum += (tick.dAsk + tick.dBid ) / 2;
            }

            return dSum / nPeriod;
        }

        public double getMA_min(int nPeriod, EPRICE nPriceMode = EPRICE.MODE_BID, int nShift = 0)
        {
            double dSum = 0;
            if (nPeriod == 0)
                return 0;
            TRatesMin min;
            for (int i = nShift; i < nPeriod + nShift; i++)
            {
                min = getMin(i);
                if (nPriceMode == EPRICE.MODE_BID)
                    dSum += min.dBid_close;

                if (nPriceMode == EPRICE.MODE_ASK)
                    dSum += min.dAsk_close;

                if (nPriceMode == EPRICE.MODE_MIDDLE)
                    dSum += (min.dAsk_close + min.dBid_close) / 2;
            }

            return dSum / nPeriod;
        }
        public double getStd_tick(int nPeriod, EPRICE nPriceMode = EPRICE.MODE_BID)
        {
            double dSum = 0;
            double dVal = 0;
            if (nPeriod == 0)
                return 0;

            double dMA = getMA_tick(nPeriod, nPriceMode);

            TRatesTick tick;
            for (int i = 0; i < nPeriod; i++)
            {
                tick = getTick(i);
                if (nPriceMode == EPRICE.MODE_BID) dVal = tick.dBid;
                if (nPriceMode == EPRICE.MODE_ASK) dVal = tick.dAsk;
                if (nPriceMode == EPRICE.MODE_MIDDLE) dVal = (tick.dAsk + tick.dBid) / 2;
                dSum += (dVal - dMA) * (dVal - dMA);
            }

            return Math.Sqrt(dSum / nPeriod);
        }
        public void getMinMax_tick(int nPeriod, ref int nMinPos, ref int nMaxPos, ref double dMin, ref double dMax, EPRICE nPriceMode = EPRICE.MODE_BID, int nPeriodMilliSec = -1)
        {
            TRatesTick tick;
            double dVal = 0;
            dMin = 100000;
            dMax = 0;
            nMinPos = 0;
            nMaxPos = 0;
            for ( int i = 0; i < nPeriod; i ++ )
            {
                tick = getTick(i);
                if (nPeriodMilliSec > 0 && i > 0)
                {
                    if ((CFATCommon.m_dtCurTime - tick.m_dtTime).TotalMilliseconds >= nPeriodMilliSec)
                        break;
                }
                if (nPriceMode == EPRICE.MODE_BID) dVal = tick.dBid;
                if (nPriceMode == EPRICE.MODE_ASK) dVal = tick.dAsk;
                if (nPriceMode == EPRICE.MODE_MIDDLE) dVal = (tick.dAsk + tick.dBid) / 2;
                if ( dVal > dMax)
                {
                    dMax = dVal;
                    nMaxPos = i;
                }
                if ( dVal < dMin)
                {
                    dMin = dVal;
                    nMinPos = i;
                }
            }
        }
        public double getStd_min(int nPeriod, EPRICE nPriceMode = EPRICE.MODE_BID)
        {
            double dSum = 0;
            double dVal = 0;
            if (nPeriod == 0)
                return 0;

            double dMA = getMA_min(nPeriod, nPriceMode);

            TRatesMin min;
            for (int i = 0; i < nPeriod; i++)
            {
                min = getMin(i);
                if (nPriceMode == EPRICE.MODE_BID) dVal = min.dBid_close;
                if (nPriceMode == EPRICE.MODE_ASK) dVal = min.dAsk_close;
                if (nPriceMode == EPRICE.MODE_MIDDLE) dVal = (min.dAsk_close + min.dBid_close) / 2;
                dSum += (dVal - dMA) * (dVal - dMA);
            }

            return Math.Sqrt(dSum / nPeriod);
        }

    }
}
