﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using FATsys.Utils;

namespace FATsys.Logic
{
    class CLogic_Gold_LatencyV3 : CLogic
    {
        public const int ID_SHANGHAI = 0;
        public const int ID_LONDON = 1;
        public const int ID_USDCNY = 2;

        int ex_nSessionTime = 200;
        int ex_nDelayTime = 3;

        double ex_dStopLossRatio = 1.2;
        int ex_nLossTime = 12000;

        double ex_dOpenLevelStart = 0.5;
        double ex_dOpenLevelEnd = 1.5;
        double ex_dCloseLevel = 0.2;
        double ex_dSlippage = 0.085;
        double ex_dSL = 0.5;

        double m_dBid_Shanghai;
        double m_dAsk_Shanghai;
        double m_dAvgPrice_Shanghai;

        double m_dBid_London;
        double m_dAsk_London;
        double m_dAvgPrice_London;

        double m_dAvgBid_London;

        double m_dBid_London_prev;
        double m_dAsk_London_prev;

        double g_dOpen_London;
        bool m_bIsNeedCheckPosition = true;
        int m_nOpen_Ticks = 0;
        double m_dExpectTp = 0;

        ETRADER_OP lastPosType = 0;
        DateTime lastPosTime;

        public override bool OnInit()
        {
            lastPosType = 0;
            loadParams();
            return base.OnInit();
        }
        public override void OnDeInit()
        {

            base.OnDeInit();
        }
        /// <summary>
        /// Called with every tick
        /// </summary>
        public override int OnTick()
        {
            getRates();
            if (checkPosMatch())
            {
                checkForClose();
                checkForOpen();
            }
            publishToMQ();//For Manager
            return base.OnTick();
        }

        private bool checkPosMatch()
        {
            if (CFATManager.m_nRunMode != ERUN_MODE.REALTIME)
                return true;

            if (!m_bIsNeedCheckPosition)// if need to check position 
                return true;

            if (!m_products[ID_SHANGHAI].isPositionMatch())
                return false;

            m_bIsNeedCheckPosition = false;// Set as don't need check pasition 

            return true;
        }
        private void publishToMQ()
        {
            if (CFATManager.m_nRunMode == ERUN_MODE.BACKTEST || CFATManager.m_nRunMode == ERUN_MODE.OPTIMIZE)
                return;

            if ((DateTime.Now - m_dtLastPublish).TotalSeconds < 2) //every 2 seconds publish message
                return;
            try
            {
                //parameters : 
                publishParams();

                //variables : logic_id@name1,val1@name2,val2@name3,val3.....
                string sTxt = string.Format("{0}@isNeedCheckPosition,{1}@sh_ask,{2}@sh_bid,{3}@ld_ask,{4}@ld_bid,{5}@g_dOpen_London,{6}@m_dExpectTp,{7}@posCnt,{8}@real lots,{9}@ex_nIsNewOrder,{10}@lastPosType,{11}@lastPosTime,{12}@m_nOpen_Ticks,{13}",
                    m_sLogicID,
                    m_bIsNeedCheckPosition,
                    m_dAsk_Shanghai, m_dBid_Shanghai,
                    m_dAsk_London, m_dBid_London,
                    g_dOpen_London, m_dExpectTp,
                    m_products[ID_SHANGHAI].getPosCount(), m_products[ID_SHANGHAI].getPosLots_real(), 
                    ex_nIsNewOrder, lastPosType, lastPosTime, m_nOpen_Ticks);

                CMQClient.publish_msg(sTxt, CFATCommon.MQ_TOPIC_VARS);
                m_dtLastPublish = DateTime.Now;
            }
            catch
            {
                CFATLogger.output_proc("CLogic_gold_latencyV2 : publishToMQ error!");
            }
        }

        public override void loadParams()
        {

            ex_dStopLossRatio = m_params.getVal_double("ex_dStopLossRatio");
            ex_dOpenLevelStart = m_params.getVal_double("ex_dOpenLevelStart");
            ex_dOpenLevelEnd = m_params.getVal_double("ex_dOpenLevelEnd");
            ex_nDelayTime = (int)m_params.getVal_double("ex_nDelayTime");
            ex_dCloseLevel = m_params.getVal_double("ex_dCloseLevel");
            ex_nSessionTime = (int)m_params.getVal_double("ex_nSessionTime");
            ex_nLossTime = (int)m_params.getVal_double("ex_nLossTime");
            ex_dSlippage = m_params.getVal_double("ex_dSlippage");
            ex_dSL = m_params.getVal_double("ex_dSL");
            base.loadParams();
        }

        private void getRates()
        {
            m_dBid_Shanghai = m_products[ID_SHANGHAI].getBid();
            m_dAsk_Shanghai = m_products[ID_SHANGHAI].getAsk();
            m_dAvgPrice_Shanghai = (m_dBid_Shanghai + m_dAsk_Shanghai) / 2;

            m_dBid_London = m_products[ID_LONDON].getBid();
            m_dAsk_London = m_products[ID_LONDON].getAsk();
            m_dAvgPrice_London = (m_dBid_London + m_dAsk_London) / 2;

            if (m_dBid_London_prev != m_dBid_London || m_dAsk_London_prev != m_dAsk_London)
            {
                m_nOpen_Ticks++;
                m_dBid_London_prev = m_dBid_London;
                m_dAsk_London_prev = m_dAsk_London;
            }

        }

        private bool isMarketCloseTime_forClose()
        {
            //02:29~02:30, 15:29~15:30 close order
            DateTime dtCurTime = m_products[ID_SHANGHAI].getTickTime();
            int nCurTime = dtCurTime.Hour * 60 + dtCurTime.Minute;
            if (nCurTime >= 2 * 60 + 28 && nCurTime <= 2 * 60 + 30)
                return true;

            if (nCurTime >= 15 * 60 + 28 && nCurTime <= 15 * 60 + 30)
                return true;

            return false;
        }
        private void checkForClose()
        {
            if (m_products[ID_SHANGHAI].getPosCount() == 0)
                return;

            ETRADER_OP nCmd = m_products[ID_SHANGHAI].getPosCmd(0);
            ETRADER_OP nCloseCmd = TRADER.getCloseCmd(nCmd);

            if (isMarketCloseTime_forClose())
            {
                //m_products[ID_SHANGHAI].reqCloseAll("Market Time Close");
                CFATLogger.output_proc("marketTime Close");
                requestOrder(nCloseCmd);
                return;
            }

            //Check TP & SL
            double dProfit = m_products[ID_SHANGHAI].getPosProfit_virtual(0);

            if (dProfit <= ex_dSL * (-1))
            {
                //m_products[ID_SHANGHAI].reqCloseAll("SL_Close");
                CFATLogger.output_proc("SL Close");
                requestOrder(nCloseCmd);
                return;
            }

            //Check MA cross
            int nSignal = getSignal();

            if (nCmd == ETRADER_OP.BUY && TRADER.isContain(nSignal, (int)ETRADER_OP.BUY_CLOSE))
            {
                //m_products[ID_SHANGHAI].reqCloseAll();
                requestOrder(ETRADER_OP.BUY_CLOSE);
                return;
            }

            if (nCmd == ETRADER_OP.SELL && TRADER.isContain(nSignal, (int)ETRADER_OP.SELL_CLOSE))
            {

                //m_products[ID_SHANGHAI].reqCloseAll();
                requestOrder(ETRADER_OP.SELL_CLOSE);
                return;
            }
        }

        private bool isMarketCloseTime_forOpen()
        {
            //02:25~02:30, 15:25~15:30 there is no enter.
            DateTime dtCurTime = m_products[ID_SHANGHAI].getTickTime();
            int nCurTime = dtCurTime.Hour * 60 + dtCurTime.Minute;
            if (nCurTime >= 2 * 60 + 25 && nCurTime <= 2 * 60 + 30)
                return true;

            if (nCurTime >= 15 * 60 + 25 && nCurTime <= 15 * 60 + 30)
                return true;
            return false;
        }

        private void requestOrder(ETRADER_OP nCmd)
        {
            double dLots = ex_dLots;
            double dPrice = 0;
            double dCurPrice = 0;
            if (nCmd == ETRADER_OP.BUY || nCmd == ETRADER_OP.SELL_CLOSE)
            {//Buy or SellClose
                dCurPrice = m_dAsk_Shanghai;
                dPrice = m_dAsk_Shanghai + ex_dSlippage;
            }
            else//Sell or BuyClose
            {
                dCurPrice = m_dBid_Shanghai;
                dPrice = m_dBid_Shanghai - ex_dSlippage;
            }

            if (nCmd == ETRADER_OP.BUY || nCmd == ETRADER_OP.SELL)
            {
                g_dOpen_London = m_dAvgBid_London;
                m_nOpen_Ticks = 1;
            }

            //For BackTest
            if (!CFATManager.isOnlineMode())
            {
                m_products[ID_SHANGHAI].reqOrder(nCmd, ref dLots, ref dPrice, EORDER_TYPE.MARKET);
                if(nCmd == ETRADER_OP.BUY_CLOSE)
                {
                    lastPosType = ETRADER_OP.BUY;
                    lastPosTime = m_products[ID_LONDON].getTickTime();
                }
                if(nCmd == ETRADER_OP.SELL_CLOSE)
                {
                    lastPosType = ETRADER_OP.SELL;
                    lastPosTime = m_products[ID_LONDON].getTickTime();
                }
                return;
            }

            //For RealTime
            if (nCmd == ETRADER_OP.BUY_CLOSE || nCmd == ETRADER_OP.SELL_CLOSE)
            {
                if (ex_nIsNewOrder <= 0)
                    ex_nIsNewOrder = 1;
                if (nCmd == ETRADER_OP.BUY_CLOSE)
                {
                    lastPosType = ETRADER_OP.BUY;
                    lastPosTime = m_products[ID_LONDON].getTickTime();
                }
                if (nCmd == ETRADER_OP.SELL_CLOSE)
                {
                    lastPosType = ETRADER_OP.SELL;
                    lastPosTime = m_products[ID_LONDON].getTickTime();
                }

            }

            if (ex_nIsNewOrder > 0)
            {
                CFATLogger.output_proc(string.Format("Request order, cmd = {0}, current price ={1}, request price = {2}, request lost = {3}", TRADER.cmdString(nCmd), dCurPrice, dPrice, dLots));
                m_products[ID_SHANGHAI].reqOrder(nCmd, ref dLots, ref dPrice, EORDER_TYPE.MARKET);
                CFATLogger.output_proc(string.Format("Response order, response price = {0}, response lost = {1}", dPrice, dLots));
                ex_nIsNewOrder--;
                m_bIsNeedCheckPosition = true;
            }
            else
                CFATLogger.output_proc(string.Format("new Signal = {0}, ex_nIsNewOrder = {1}", TRADER.cmdString(nCmd), ex_nIsNewOrder));

        }

        private void checkForOpen()
        {
            if (m_products[ID_SHANGHAI].getPosCount() == 1)
                return;

            DateTime dtCurTime = m_products[ID_SHANGHAI].getTickTime();

            if (isMarketCloseTime_forOpen())
                return;

            int nSignal = getSignal();

            if (TRADER.isContain(nSignal, (int)ETRADER_OP.BUY))
                requestOrder(ETRADER_OP.BUY);

            if (TRADER.isContain(nSignal, (int)ETRADER_OP.SELL))
                requestOrder(ETRADER_OP.SELL);
        }

        private bool CanBuy()
        {
            if (lastPosType == ETRADER_OP.BUY && (int)(m_products[ID_LONDON].getTickTime() - lastPosTime).TotalSeconds < 60)
                return false;

            if (lastPosType == ETRADER_OP.SELL && (int)(m_products[ID_LONDON].getTickTime() - lastPosTime).TotalSeconds < 120)
                return false;
            //For Log
            DateTime dtLog = m_products[ID_SHANGHAI].getTickTime();
            if (dtLog.Day ==18 &&  dtLog.Hour == 22 && dtLog.Minute == 27 && dtLog.Second == 4)
            {

            }

            m_dAvgBid_London = 0;
            int nCnt = 0;
            for(int i = 0; i < m_products[ID_LONDON].getTick_count()-1; i ++)
            {
                if ((m_products[ID_LONDON].getTick(i).m_dtTime - m_products[ID_LONDON].getTick(i + 1).m_dtTime).TotalSeconds > 300)
                    break;
                int difftime = 0;
                if ( i > 0)
                    difftime = (int)(m_products[ID_LONDON].getTickTime() - m_products[ID_LONDON].getTick(i-1).m_dtTime).TotalSeconds;
                if (difftime <= ex_nDelayTime)
                {
                    m_dAvgBid_London += m_products[ID_LONDON].getTick(i).dBid;
                    nCnt++;
                    double dExpectDiff = ex_dOpenLevelStart + (ex_dOpenLevelEnd - ex_dOpenLevelStart) * difftime / ex_nDelayTime;
                    if ( (m_products[ID_LONDON].getTick(0).dBid - m_products[ID_LONDON].getTick(i).dBid > dExpectDiff) &&
                        (m_products[ID_LONDON].getTick(0).dAsk - m_products[ID_LONDON].getTick(i).dAsk > dExpectDiff))
                    {
                        m_dAvgBid_London /= nCnt;
                        return true;
                    }
                }
                else break;
            }
            return false;
        }

        private bool CanSell()
        {
            if (lastPosType == ETRADER_OP.SELL && (int)(m_products[ID_LONDON].getTickTime() - lastPosTime).TotalSeconds < 60)
                return false;

            if (lastPosType == ETRADER_OP.BUY && (int)(m_products[ID_LONDON].getTickTime() - lastPosTime).TotalSeconds < 120)
                return false;


            m_dAvgBid_London = 0;
            int nCnt = 0;
            for (int i = 0; i < m_products[ID_LONDON].getTick_count(); i++)
            {
                if ((m_products[ID_LONDON].getTick(i).m_dtTime - m_products[ID_LONDON].getTick(i + 1).m_dtTime).TotalSeconds > 300)
                    break;

                int difftime = 0;
                if ( i > 0)
                    difftime = (int)(m_products[ID_LONDON].getTickTime() - m_products[ID_LONDON].getTick(i-1).m_dtTime).TotalSeconds;
                if (difftime <= ex_nDelayTime)
                {
                    m_dAvgBid_London += m_products[ID_LONDON].getTick(i).dAsk;
                    nCnt++;
                    double dExpectDiff = ex_dOpenLevelStart + (ex_dOpenLevelEnd - ex_dOpenLevelStart) * difftime / ex_nDelayTime;
                    if ( (m_products[ID_LONDON].getTick(i).dBid - m_products[ID_LONDON].getTick(0).dBid > dExpectDiff) &&
                        (m_products[ID_LONDON].getTick(i).dAsk - m_products[ID_LONDON].getTick(0).dAsk > dExpectDiff) )
                    {
                        m_dAvgBid_London /= nCnt;
                        return true;
                    }
                }
                else break;
            }
            return false;
        }

        private int getSignal()
        {


            int nRetSignal = (int)ETRADER_OP.NONE;
            if (CanBuy())
            {
                nRetSignal |= (int)ETRADER_OP.BUY;
            }
            else if(CanSell())
            {
                nRetSignal |= (int)ETRADER_OP.SELL;
            }


            //Close signal
            if (m_products[ID_SHANGHAI].getPosCount() == 0) return nRetSignal;

            ETRADER_OP nCmd = m_products[ID_SHANGHAI].getPosCmd(0);// == TRADER.BUY ? 0 : 1;


            m_dExpectTp = 0;
            int nSessionTime = m_nOpen_Ticks;

            if (m_nOpen_Ticks >= ex_nSessionTime)
                nSessionTime = ex_nSessionTime;


            if (nCmd == ETRADER_OP.BUY)
                m_dExpectTp = m_products[ID_LONDON].getMA_tick(nSessionTime, EPRICE.MODE_BID) - ex_dStopLossRatio * (ex_nLossTime - m_nOpen_Ticks) / ex_nLossTime;
            else if (nCmd == ETRADER_OP.SELL)
                m_dExpectTp = m_products[ID_LONDON].getMA_tick(nSessionTime, EPRICE.MODE_BID) + ex_dStopLossRatio * (ex_nLossTime - m_nOpen_Ticks) / ex_nLossTime;

            if (nCmd == ETRADER_OP.BUY && m_dBid_London < m_dExpectTp)
            {
                CFATLogger.output_proc(string.Format("m_dExpectTp Close = {0}", m_dExpectTp));
                nRetSignal |= (int)ETRADER_OP.BUY_CLOSE;
            }

            if (nCmd == ETRADER_OP.BUY && m_dAsk_London < g_dOpen_London + ex_dCloseLevel)
            {
                CFATLogger.output_proc(string.Format("ex_dCloseLevel Close = {0}", g_dOpen_London));
                nRetSignal |= (int)ETRADER_OP.BUY_CLOSE;
            }

            if (nCmd == ETRADER_OP.SELL && m_dBid_London > m_dExpectTp)
            {
                CFATLogger.output_proc(string.Format("m_dExpectTp Close = {0}", m_dExpectTp));
                nRetSignal |= (int)ETRADER_OP.SELL_CLOSE;
            }

            if (nCmd == ETRADER_OP.SELL && m_dBid_London > g_dOpen_London - ex_dCloseLevel)
            {
                CFATLogger.output_proc(string.Format("ex_dCloseLevel Close = {0}", g_dOpen_London));
                nRetSignal |= (int)ETRADER_OP.SELL_CLOSE;
            }

            return nRetSignal;
        }
    }
}
