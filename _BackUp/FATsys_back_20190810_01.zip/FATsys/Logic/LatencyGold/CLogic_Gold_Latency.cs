﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using FATsys.Utils;

namespace FATsys.Logic
{
    class CLogic_Gold_Latency : CLogic
    {
        public const int ID_SHANGHAI = 0;
        public const int ID_LONDON = 1;
        public const int ID_USDCNY = 2;

        int ex_nMAPeriod;
        int ex_nLossTime;
        int ex_nTicksOpen;
        double ex_dOpenLevel;
        double ex_dCloseLevel;
        double ex_dSlippage;
        double ex_dTP;
        double ex_dSL;

        int m_nOpen_Ticks = 0;
        double m_dBid_Shanghai;
        double m_dAsk_Shanghai;
        double m_dAvgPrice_Shanghai;

        double m_dBid_London;
        double m_dAsk_London;
        double m_dAvgPrice_London;

        double m_dTrailingStop;

        public override bool OnInit()
        {
            loadParams();
            return base.OnInit();
        }
        public override void OnDeInit()
        {
            
            base.OnDeInit();
        }

        /// <summary>
        /// Called with every tick
        /// </summary>
        public override int OnTick()
        {
            m_nOpen_Ticks++;
            getRates();
            checkForClose();
            checkForOpen();
            return base.OnTick();
        }

        public override void loadParams()
        {
            ex_nMAPeriod = (int)m_params.getVal_double("ex_nMAPeriod");
            ex_nLossTime = (int)m_params.getVal_double("ex_nLossTime");
            ex_nTicksOpen = (int)m_params.getVal_double("ex_nTicksOpen");
            ex_dOpenLevel = m_params.getVal_double("ex_dOpenLevel");
            ex_dCloseLevel = m_params.getVal_double("ex_dCloseLevel");
            ex_dSlippage = m_params.getVal_double("ex_dSlippage");
            ex_dTP = m_params.getVal_double("ex_dTP");
            ex_dSL = m_params.getVal_double("ex_dSL");
            base.loadParams();
        }
        private double LD2SHPrice(double dUSD)
        {
            return dUSD / 31.103477 * m_products[ID_USDCNY].getBid();
        }
        private void getRates()
        {
            m_dBid_Shanghai = m_products[ID_SHANGHAI].getBid();
            m_dAsk_Shanghai = m_products[ID_SHANGHAI].getAsk();
            m_dAvgPrice_Shanghai = (m_dBid_Shanghai + m_dAsk_Shanghai) / 2;

            m_dBid_London = m_products[ID_LONDON].getBid();
            m_dAsk_London = m_products[ID_LONDON].getAsk();
            m_dAvgPrice_London = (m_dBid_London + m_dAsk_London) / 2;
            m_dAvgPrice_London = LD2SHPrice(m_dAvgPrice_London);
        }

        private bool isMarketCloseTime_forClose()
        {
            //02:29~02:30, 15:29~15:30 close order
            DateTime dtCurTime = m_products[ID_SHANGHAI].getTickTime();
            int nCurTime = dtCurTime.Hour * 60 + dtCurTime.Minute;
            if (nCurTime >= 2 * 60 + 29 && nCurTime <= 2 * 60 + 30)
                return true;

            if (nCurTime >= 15 * 60 + 29 && nCurTime <= 15 * 60 + 30)
                return true;

            return false;
        }
        private void checkForClose()
        {
            if (m_products[ID_SHANGHAI].getPosCount() == 0)
                return;

            if (isMarketCloseTime_forClose())
            {
                m_products[ID_SHANGHAI].reqCloseAll("Market Time Close");
                return;
            }

            //Check TP & SL
            double dProfit = m_products[ID_SHANGHAI].getPosProfit_virtual(0);
            if ( dProfit >= ex_dTP )
            {
                m_products[ID_SHANGHAI].reqCloseAll("TP_Close");
                return;
            }
            if (dProfit <= ex_dSL * (-1))
            {
                m_products[ID_SHANGHAI].reqCloseAll("SL_Close");
                return;
            }

            //Check MA cross
            int nSignal = getSignal();
            ETRADER_OP nCmd = m_products[ID_SHANGHAI].getPosCmd(0);

            if (nCmd == ETRADER_OP.BUY && TRADER.isContain(nSignal, (int)ETRADER_OP.BUY_CLOSE))
            {
                m_products[ID_SHANGHAI].reqCloseAll();
                return;
            }

            if (nCmd == ETRADER_OP.SELL && TRADER.isContain(nSignal, (int)ETRADER_OP.SELL_CLOSE))
            {
                m_products[ID_SHANGHAI].reqCloseAll();
                return;
            }
        }

        private bool isMarketCloseTime_forOpen()
        {
            //02:25~02:30, 15:25~15:30 there is no enter.
            DateTime dtCurTime = m_products[ID_SHANGHAI].getTickTime();
            int nCurTime = dtCurTime.Hour * 60 + dtCurTime.Minute;
            if (nCurTime >= 2 * 60 + 25 && nCurTime <= 2 * 60 + 30)
                return true;

            if (nCurTime >= 15 * 60 + 25 && nCurTime <= 15 * 60 + 30)
                return true;
            return false;
        }

        private void checkForOpen()
        {
            if (m_products[ID_SHANGHAI].getPosCount() == 1)
                return;

            if (isMarketCloseTime_forOpen())
                return;

            int nSignal = getSignal();

            double dLots = 1;
            double dPrice = 0;
            //A : Buy, B : Sell
            if (TRADER.isContain(nSignal, (int)ETRADER_OP.BUY))
            {
                m_nOpen_Ticks = 0;
                dPrice = m_dAsk_Shanghai + ex_dSlippage;
                m_products[ID_SHANGHAI].reqOrder(ETRADER_OP.BUY, ref dLots, ref dPrice, EORDER_TYPE.MARKET);
                m_dTrailingStop = m_dBid_London - ex_dCloseLevel;
                //m_products[ID_LONDON].reqOrder(ETRADER_OP.SELL, 0, EORDER_TYPE.MARKET);
                return;
            }

            //CheckFor Sell : A Sell & B Buy
            if (TRADER.isContain(nSignal, (int)ETRADER_OP.SELL))
            {
                m_nOpen_Ticks = 0;
                dPrice = m_dBid_Shanghai - ex_dSlippage;
                m_products[ID_SHANGHAI].reqOrder(ETRADER_OP.SELL, ref dLots, ref dPrice, EORDER_TYPE.MARKET);
                //m_products[ID_LONDON].reqOrder(ETRADER_OP.BUY, 0, EORDER_TYPE.MARKET);
                m_dTrailingStop = m_dAsk_London + ex_dCloseLevel;
                return;
            }
        }

        private int getSignal()
        {
            int nRetSignal = (int)ETRADER_OP.NONE;
            if (m_products[ID_LONDON].getTick_count() < ex_nMAPeriod)
                return nRetSignal;
            TraderType.TRatesTick tickVal;
            tickVal = m_products[ID_SHANGHAI].getTick(ex_nTicksOpen);
            double dSH_ma = (tickVal.dAsk + tickVal.dBid) / 2;

            tickVal = m_products[ID_LONDON].getTick(ex_nTicksOpen);
            double dLD_ma = LD2SHPrice((tickVal.dAsk + tickVal.dBid) / 2);

            double dSH_diff = m_dAvgPrice_Shanghai - dSH_ma;
            double dLD_diff = m_dAvgPrice_London - dLD_ma;

            //CheckFor Buy :
            if (dLD_diff > ex_dOpenLevel)
                nRetSignal |= (int)ETRADER_OP.BUY;

            //CheckFor Sell :
            if ( dLD_diff < ex_dOpenLevel * (-1))
                nRetSignal |= (int)ETRADER_OP.SELL;

            if (m_products[ID_SHANGHAI].getPosCount() == 0) return nRetSignal;
            ETRADER_OP nCmd = m_products[ID_SHANGHAI].getPosCmd(0);
            
            dLD_ma = LD2SHPrice(m_products[ID_LONDON].getMA_tick(ex_nMAPeriod, EPRICE.MODE_MIDDLE));

            double dTrailingStop = ex_dCloseLevel - ex_dCloseLevel *  m_nOpen_Ticks / ex_nLossTime;

            /*
            double dTrailingStep = ex_dCloseLevel - ex_dCloseLevel * m_nOpen_Ticks / ex_nLossTime;
            double dTradingStop = 0;
            if ( nCmd == TRADER.BUY )
            {
                dTradingStop = m_dBid_London - dTrailingStep;
                if (m_dTrailingStop < dTradingStop)
                    m_dTrailingStop = dTradingStop;
            }
            if ( nCmd == TRADER.SELL)
            {
                dTradingStop = m_dAsk_London + dTrailingStep;
                if (m_dTrailingStop > dTradingStop)
                    m_dTrailingStop = dTradingStop;
            }
            m_dTrailingStop = LD2SHPrice(m_dTrailingStop);
            */
            //CheckFor Buy Close : 
            if ( m_dAvgPrice_London < dLD_ma - dTrailingStop)
            //if (m_dAvgPrice_London < m_dTrailingStop)
                nRetSignal |= (int)ETRADER_OP.BUY_CLOSE;

            //CheckFor Sell Close: 
            if (m_dAvgPrice_London > dLD_ma + dTrailingStop)
            //if (m_dAvgPrice_London > m_dTrailingStop)
                nRetSignal |= (int)ETRADER_OP.SELL_CLOSE;

            return nRetSignal;
        }

    }
}
