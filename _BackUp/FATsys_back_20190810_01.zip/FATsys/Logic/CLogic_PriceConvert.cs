﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using FATsys.Utils;
using FATsys.TraderType;

namespace FATsys.Logic
{
    class CLogic_PriceConvert : CLogic
    {
        public const int ID_SHANGHAI = 0;
        public const int ID_LONDON = 1;
        private List<DateTime> m_lstMinTime;
        private List<DateTime> m_lstMaxTime;
        public override bool OnInit()
        {
            loadParams();
            m_lstMinTime = new List<DateTime>();
            m_lstMaxTime = new List<DateTime>();
            return base.OnInit();
        }

        public override void OnDeInit()
        {
            base.OnDeInit();
        }

        public override int OnTick()
        {
            int nMinPos = 0;
            int nMaxPos = 0;
            double dMin = 0;
            double dMax = 0;

            m_products[ID_LONDON].getMinMax_tick(500, ref nMinPos, ref nMaxPos, ref dMin, ref dMax);

            if (dMax - dMin < 4) // 2$ over period
            {
                return base.OnTick();
            }

            int nStart = Math.Max(nMinPos, nMaxPos);
            int nEnd = Math.Min(nMinPos, nMaxPos);

            if ( nEnd < 100 || nStart > 400 )
            {
                return base.OnTick();
            }

            TRatesTick tickVal;
            tickVal = m_products[ID_LONDON].getTick(nMinPos);
            DateTime dtMin = tickVal.m_dtTime;
            tickVal = m_products[ID_LONDON].getTick(nMaxPos);
            DateTime dtMax = tickVal.m_dtTime;

            if ( m_lstMinTime.Contains(dtMin) && m_lstMaxTime.Contains(dtMax) )
            {
                return base.OnTick();
            }

            m_lstMinTime.Add(dtMin);
            m_lstMaxTime.Add(dtMax);



            string sRates;
            string sFirstLine = "";
            for ( int i = nStart; i >=nEnd; i --)
            {
                tickVal = m_products[ID_SHANGHAI].getTick(i);
                sRates = tickVal.m_dtTime.ToString("yyyy/MM/dd HH:mm:ss.fff");
                sRates += string.Format(",{0},{1}", tickVal.dAsk, tickVal.dBid);
                tickVal = m_products[ID_LONDON].getTick(i);
                sRates += string.Format(",{0},{1}", tickVal.dAsk, tickVal.dBid);
                if (sFirstLine == "")
                    sFirstLine = sRates;

                CFATLogger.record_rates("SHGOLD", sRates);
            }

            CFATLogger.record_rates("SHGOLD", sFirstLine);

            return base.OnTick();
        }
    }
    }
